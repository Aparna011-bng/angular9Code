// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

import { APP_CONSTANTS } from 'src/app/constants';

export const environment = {
  production: false,
  SERVICE_APIS: {
    ATTEMPT_LOGIN: APP_CONSTANTS.URI + '/api/v1/login',
    GET_ASSESSMENT_DATA: APP_CONSTANTS.URI + '/api/v1/student/dashboard/assessment/',
    GET_PERSONALITY_TEST_DATA: APP_CONSTANTS.URI + '/api/v1/assessment/personality/test/student/',
    POST_PERSONALITY_TEST_RESULT: APP_CONSTANTS.URI + '/api/v1/assessment/personality/testResponse',
    GET_APTITUDE_REASONING_TEST: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/ra/test/student/',
    POST_APTITUDE_REASONING_TEST_RESULT: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/ra/testResponse',
    GET_APTITUDE_VERBAL_TEST: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/va/test/student/',
    POST_APTITUDE_VERBAL_TEST_RESULT: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/va/testResponse',
    GET_APTITUDE_MECH_TEST: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/ma/test/student/',
    POST_APTITUDE_MECH_TEST_RESULT: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/ma/testResponse',
    GET_APTITUDE_SPATIAL_TEST: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/sa/test/student/',
    POST_APTITUDE_SPATIAL_TEST_RESULT: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/sa/testResponse',
    GET_DASHBOARD_DATA: APP_CONSTANTS.URI + '/api/v1/student/dashboard/home',
    // GET_DASHBOARD_STATIC_DATA: 'http://eduguy.ibm.dev.s3.ap-south-1.amazonaws.com/static-data/dashboard-static-data.5.json',
    GET_REPORT_DATA: APP_CONSTANTS.URI + '/api/v1/report/student/',
    //GET_REPORT_DATA: APP_CONSTANTS.URI + '/api/v1/report/student/',
    // POST_DEMO_API: APP_CONSTANTS.URI + '/api/v1/demo',
    GET_APTITUDE_NUMERICAL_TEST: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/na/test/student/',
    POST_APTITUDE_NUMERICAL_TEST_RESULT: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/na/testResponse',
    GET_APTITUDE_CLOSURE_TEST: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/ca/test/student/',
    POST_APTITUDE_CLOSURE_TEST_RESULT: APP_CONSTANTS.URI + '/api/v1/assessment/aptitude/ca/testResponse',
    GET_INTEREST_TEST_DATA: APP_CONSTANTS.URI + '/api/v1/assessment/interest/test/student/',
    POST_INTEREST_TEST_RESULT: APP_CONSTANTS.URI + '/api/v1/assessment/interest/testResponse',
    GET_STUDENT_PROFILE_TEST_DATA: APP_CONSTANTS.URI + '/api/v1/studentProfile/'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
