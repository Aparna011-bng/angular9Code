import { Injectable } from '@angular/core';
import { HttpRequestService } from '../http-request.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DashboardApiService {

  constructor(private _httpReqService: HttpRequestService) { }

  public getDashboardData(query: {student_id: string}, token) {
    return this._httpReqService.request({
      params: query,
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_DASHBOARD_DATA,
      headerConfig: {token: token}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  // Login POST Call
  // public postLoginInfo(requestBody: { email, password }) {
  //   return this._httpReqService.request({
  //     method: APP_CONSTANTS.API_METHODS.POST,
  //     url: environment.SERVICE_APIS.ATTEMPT_LOGIN,
  //     body: requestBody
  //   })
  // }

  // public demoApiCall(requestBody: {student_id, assessment_id}){
  //   return this._httpReqService.request({
  //     method: APP_CONSTANTS.API_METHODS.POST,
  //     url: environment.SERVICE_APIS.POST_DEMO_API,
  //     body: requestBody
  //   })
  //     .pipe(
  //       map(response => this._extractResponse(response))
  //     );
  // }
  private _extractResponse = (response: { data: any, status: number }) => {
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data;
    } 
    else if(response.status === (APP_CONSTANTS.LOGOUT_ERROR_CODES[0] || APP_CONSTANTS.LOGOUT_ERROR_CODES[1])) {
      console.log(response.data);
      return response.data;
    }
    else {
      return false;
    }
  }
}
