import { TestBed } from '@angular/core/testing';

import { TakeAssessmentService } from './take-assessment.service';

describe('TakeAssessmentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TakeAssessmentService = TestBed.get(TakeAssessmentService);
    expect(service).toBeTruthy();
  });
});
