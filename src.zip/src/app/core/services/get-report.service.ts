import { Injectable } from '@angular/core';
import { HttpRequestService } from '../http-request.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class GetReportService {

  constructor(private _httpReqService: HttpRequestService) { }

  //  GET Report Data
  //public getReportData(studentId, token) {
  public getReportData(studentId, token) {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_REPORT_DATA + studentId,
      headerConfig: {token: token} 
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }
  private _extractResponse = (response: { data: any, status: number }) => {
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data;
    } else {
      return false;
    }
  }
}