import { Injectable } from '@angular/core';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { HttpRequestService } from '../http-request.service';
import { map } from 'rxjs/operators';
import { Subject, Observable, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class TokenService {
  private _tokenProviderSubject: BehaviorSubject<string>;
  public tokenProviderObservable$: Observable<string>;
  public globalTokenVal: string

  constructor(private _httpReqService: HttpRequestService, private _router: Router) {
    this._tokenProviderSubject = new BehaviorSubject(null);
    this.tokenProviderObservable$ = this._tokenProviderSubject.asObservable();
   }
  // Login POST Call
  public postLoginInfo(requestBody: { email, password, targetURL }) {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.ATTEMPT_LOGIN,
      body: requestBody
      // headerConfig: 
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }
  
  // Create Subject Observable
  public setTokenVal(receivedStudentInfo) {
    // this.globalTokenVal = receivedStudentInfo.token
    this._tokenProviderSubject.next(receivedStudentInfo);
  }

  private _extractResponse = (response: { data: any, status: number, headers: any }) => {
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response;
    }
    else if (response.status === (APP_CONSTANTS.LOGOUT_ERROR_CODES[0] || APP_CONSTANTS.LOGOUT_ERROR_CODES[1])) {
      this._router.navigate(['/login']);
      return response;
      // Redirect to Login page
    }
    else {
      return false;
    }
  }
}
