import { Injectable } from '@angular/core';
import { HttpRequestService } from '../http-request.service';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentProfileService {

  constructor(private _httpReqService: HttpRequestService) { }

  public getStudentData(studentId, token) {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_STUDENT_PROFILE_TEST_DATA + studentId,
      headerConfig: {token: token}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  private _extractResponse = (response: { data: any, status: number }) => {
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data;
    } else {
      return false;
    }
  }

}
