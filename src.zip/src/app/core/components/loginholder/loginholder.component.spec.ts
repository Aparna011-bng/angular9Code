import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginholderComponent } from './loginholder.component';

describe('LoginholderComponent', () => {
  let component: LoginholderComponent;
  let fixture: ComponentFixture<LoginholderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginholderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginholderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
