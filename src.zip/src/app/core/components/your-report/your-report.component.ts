import { Component, OnInit, ViewChild, ElementRef, Input, ChangeDetectionStrategy } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { GetReportService } from '../../services/get-report.service';
import * as jsPDF from 'jspdf';
import * as html2canvas from 'html2canvas';
import { TokenService } from '../../services/token.service';

@Component({
  selector: 'app-your-report',
  templateUrl: './your-report.component.html',
  styleUrls: ['./your-report.component.scss'],
  //changeDetection: ChangeDetectionStrategy.OnPush,
})
export class YourReportComponent implements OnInit {
  // public loadAptiChart: boolean = true;
 public chartData: boolean = true;
  private _isComponentAlive: boolean = true;
  public reportheaderData: any;
  public reportData: any;
  constructor(private _getReportDataService: GetReportService, private _tokenService: TokenService) {
  }

  @ViewChild('content', { static: false }) content: ElementRef;
  @Input() advertiseData: Array<{
    id: String;
    image_url: String;
  }>;
  /* public makePdf() {
    let doc = new jsPDF('p', 'mm', [738, 400]);
    doc.addHTML(this.content.nativeElement, function () {
      doc.save("eduBuddy-report.pdf");
    });
  } */
  public makePdf() {
    var data = document.getElementById('content');
    html2canvas(data).then(canvas => {
      var contentWidth = canvas.width;
      var contentHeight = canvas.height;
      var pageHeight = contentWidth / 592.28 * 841.89;
      var leftHeight = contentHeight;
      var position = 0;
      var imgWidth = 595.28;
      var imgHeight = 592.28 / contentWidth * contentHeight;
      var pageData = canvas.toDataURL('image/png', 1.0);
      var pageData = canvas.toDataURL('image/jpeg;base64', 1.0);
      var doc = new jsPDF('', 'pt', 'a4');
      if (leftHeight < pageHeight) {
        doc.addImage(pageData, 'PNG', 0, 0, imgWidth, imgHeight);
        doc.addImage(pageData, 'JPEG', 0, 0, imgWidth, imgHeight);
      } else {
        while (leftHeight > 0) {
          doc.addImage(pageData, 'PNG', 0, position, imgWidth, imgHeight)
          doc.addImage(pageData, 'JPEG', 0, position, imgWidth, imgHeight)
          leftHeight -= pageHeight;
          position -= 841.89;
          //Avoid adding blank pages
          if (leftHeight > 0) {
            doc.addPage();
          }
        }
      }
      doc.save('eduBuddy-report.pdf');
    });
  }

  ngOnInit() {
    this.getTokenValue();
  }

  public getTokenValue() {
    this._tokenService.tokenProviderObservable$
      .pipe(
        // switchMap((data) => this._getAssessmentData(data))
      )
      .subscribe(this._getTokenValueHandler);
  }

  private _getTokenValueHandler = (data) => {
    //console.log(data.student_id);
    // console.log('Student_id' + this.student_id);
    //this._getReportData(data.student_id, data.token);
    this._getReportData(data.student_id, data.token);

    // this.assessmentData = this._getAssessmentData();
    // return forkJoin([this.assessmentData, this.tokenData ]);
  }


  private _getReportData(student_id, token) {
    this._getReportDataService.getReportData(student_id,token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._getReportDataSuccessHandler, error: this._getReportDataErrorHandler });
  }

  private _getReportDataSuccessHandler = (data) => {
    if (data) {
      this.reportData = data;
      console.log(this.reportData);
    }
  }

  private _getReportDataErrorHandler = () => {
    //error handler
  }

  // yourFn($event) {
  //   this.loadAptiChart = true;
  // }

}
