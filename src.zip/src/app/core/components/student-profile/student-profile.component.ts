import { Component, OnInit } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { StudentProfileService } from '../../services/student-profile.service';
import { TokenService } from '../../services/token.service';

@Component({
  selector: 'app-student-profile',
  templateUrl: './student-profile.component.html',
  styleUrls: ['./student-profile.component.scss']
})
export class StudentProfileComponent implements OnInit {
  public studentData: any;
  private _isComponentAlive = true;

  constructor(private _getStudentDataService: StudentProfileService, private _tokenService: TokenService) { }

  ngOnInit() {
    this.getTokenValue();
  }

  public getTokenValue() {
    this._tokenService.tokenProviderObservable$
      .pipe(
        // switchMap((data) => this._getAssessmentData(data))
      )
      .subscribe(this._getTokenValueHandler);
  }

  private _getTokenValueHandler = (data) => {

      // console.log(data.student_id);
      // console.log('Student_id' + this.student_id);
      this._getStudentStaticData(data.student_id, data.token);
      // this.tokenReceived = true;
    }
  

  private _getStudentStaticData(studentId, token) {
    this._getStudentDataService.getStudentData(studentId, token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._getStudentStaticDataSuccessHandler, error: this._getStudentStaticDataErrorHandler });
  }

  private _getStudentStaticDataSuccessHandler = (data) => {
    if (data) {
      this.studentData = data;
      console.log(this.studentData);
    }
  }

  private _getStudentStaticDataErrorHandler = () => {
    //error handler
    console.log('error')
  }

}
