import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeAssessmentsComponent } from './take-assessments.component';

describe('TakeAssessmentsComponent', () => {
  let component: TakeAssessmentsComponent;
  let fixture: ComponentFixture<TakeAssessmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeAssessmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeAssessmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
