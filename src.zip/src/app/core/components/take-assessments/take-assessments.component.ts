import { Component, OnInit } from '@angular/core';
import { TakeAssessmentService } from '../../services/take-assessment.service';
import { takeWhile} from 'rxjs/operators';
import { DatePipe } from '@angular/common';
import { TokenService } from '../../services/token.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-take-assessments',
  templateUrl: './take-assessments.component.html',
  styleUrls: ['./take-assessments.component.scss'],
  providers: [DatePipe]
})
export class TakeAssessmentsComponent implements OnInit {
  private _isComponentAlive: boolean = true;
  public assessmentData: any;
  public interestStartDate: any;
  public interestEndDate: any;
  public completedDuration: any;
  public student_id: string;
  private _token: string;
  public tokenData: any;
  value: any;
  showData: boolean;
  public diffPersonality: any;
  public diffInterest: any;
  public personalityStartDate: any;
  public personalityEndDate: any;

  public tokenReceived: boolean

  constructor(private _getAssessmentDataService: TakeAssessmentService, private _datePipe: DatePipe, private _tokenService: TokenService, private _router: Router) {

  }

  ngOnInit() {
    this.getTokenValue();

  }

  public getTokenValue() {
    this._tokenService.tokenProviderObservable$
      .pipe(
        // switchMap((data) => this._getAssessmentData(data))
      )
      .subscribe(this._getTokenValueHandler);
  }

  // getAssessmentData() {
  //   this.assessmentData$ = this._tokenService.tokenProviderObservable$.pipe(
  //     switchMap(({student_id, _token}: any) => this._getAssessmentDataService.getAssessmentData(student_id, _token)),
  //     map(i => this._getAssessmentDataSuccessHandler)
  //   )
  // }

  private _getTokenValueHandler = (data) => {

    if (data === null) {
      this._router.navigate(['/login']);
    }
    else {
      console.log(data.student_id);
      this.tokenData = data;
      this.student_id = data.student_id;
      this._token = data.token;
      console.log('Student_id' + this.student_id);
      this.tokenReceived = true;
      this._getAssessmentData();
    }

  }

  private _getAssessmentData() {
    this._getAssessmentDataService.getAssessmentData(this.student_id, this._token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
        // switchMap((data) => this.getTokenValue)
      )
      .subscribe({ next: this._getAssessmentDataSuccessHandler, error: this._getAssessmentDataErrorHandler });
  }

  private _getAssessmentDataSuccessHandler = (data) => {
    if (data) {
      this.assessmentData = data;
      console.log(this.assessmentData);
      this.personalityStartDate = this._datePipe.transform(this.assessmentData.assessment.active_attempts.personality.start_datetime, 'ss');
      this.personalityEndDate = this._datePipe.transform(this.assessmentData.assessment.active_attempts.personality.end_datetime, 'ss');
      console.log(this.personalityStartDate);
      console.log(this.personalityEndDate);
       this.diffPersonality = (this.personalityEndDate - this.personalityStartDate);


      //  Interest Time duration
      this.interestStartDate =  this._datePipe.transform(this.assessmentData.assessment.active_attempts.interest.start_datetime, 'ss');
      this.interestEndDate =  this._datePipe.transform(this.assessmentData.assessment.active_attempts.interest.end_datetime, 'ss');
      console.log(this.interestStartDate);
      console.log(this.interestEndDate);
      this.diffInterest= (this.interestEndDate - this.interestStartDate);


      this.showData = true;

    }
  }

  private _getAssessmentDataErrorHandler = (error) => {
    // error handler
    console.log(error);
  }

}
