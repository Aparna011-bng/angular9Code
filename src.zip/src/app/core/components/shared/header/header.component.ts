import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() routed: string;
  @Input() studentData: any;
  @Input() assessmentInfo: any;
  @Input() tokenReceived: boolean;
  constructor(private _router: Router) { }

  ngOnInit() {
  }

  routeToReport() {
    // if (!this.assessmentInfo[0].can_start_test && !this.assessmentInfo[1].can_start_test && !this.assessmentInfo[2].can_start_test) {
    //   this._router.navigate(['/your-report']);
    // }
    if (this.assessmentInfo.personality.status === 100 && this.assessmentInfo.aptitude.status  && this.assessmentInfo.interest.status ) {
      this._router.navigate(['/your-report']);
    }
    else {
      alert("Please complete all the tests to generate a report");
    }
  }

}
