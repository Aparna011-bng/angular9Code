import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportRadarChartComponent } from './report-radar-chart.component';

describe('ReportRadarChartComponent', () => {
  let component: ReportRadarChartComponent;
  let fixture: ComponentFixture<ReportRadarChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportRadarChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportRadarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
