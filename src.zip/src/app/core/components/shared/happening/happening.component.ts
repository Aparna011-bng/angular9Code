import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-happening',
  templateUrl: './happening.component.html',
  styleUrls: ['./happening.component.scss']
})
export class HappeningComponent implements OnInit {
  @Input() trendingData: any;
  constructor() { }

  ngOnInit() {
  }

}
