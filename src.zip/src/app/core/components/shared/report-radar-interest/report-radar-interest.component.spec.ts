import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportRadarInterestComponent } from './report-radar-interest.component';

describe('ReportRadarInterestComponent', () => {
  let component: ReportRadarInterestComponent;
  let fixture: ComponentFixture<ReportRadarInterestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportRadarInterestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportRadarInterestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
