import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportradarAptitudeComponent } from './reportradar-aptitude.component';

describe('ReportradarAptitudeComponent', () => {
  let component: ReportradarAptitudeComponent;
  let fixture: ComponentFixture<ReportradarAptitudeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportradarAptitudeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportradarAptitudeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
