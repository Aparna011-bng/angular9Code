import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts';
import { ChartsModule } from 'ng2-charts';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';

@Component({
  selector: 'app-reportradar-aptitude',
  templateUrl: './reportradar-aptitude.component.html',
  styleUrls: ['./reportradar-aptitude.component.scss']
})
export class ReportradarAptitudeComponent implements OnInit {
  public radarChartLabels: Array<String> = []; //
  public radarScores: Array<number> = []; //
  @Input() traits: Array<{attribute: string, score: number }> = [];
  @ViewChild('chartcontainer', {static: true}) public chartcontainer: ElementRef;
 
  public radarChartTypes: string = 'radar';

  public demoradarChartData = [
    { data: this.radarScores, label: '' },
  ];
  
  public chartOptions: ChartOptions = {
    responsive: true,
    maintainAspectRatio: true,
  }

  ngOnInit() {
    setTimeout(() => {
      if(this.traits) {
        //console.log(this.traits);  
        for (let i = 0; i <= this.traits.length; i++) {
          this.radarChartLabels.push(this.traits[i].attribute);
          this.radarScores.push(this.traits[i].score);
        }
        this.demoradarChartData = [
          { data: this.radarScores, label: '' }
        ];
      }
    }, 1000);
  }
}