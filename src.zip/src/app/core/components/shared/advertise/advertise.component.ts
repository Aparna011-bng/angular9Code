import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-advertise',
  templateUrl: './advertise.component.html',
  styleUrls: ['./advertise.component.scss']
})
export class AdvertiseComponent implements OnInit {
  @Input() advertiseData: Array<{
    id: String;
    image_url: String;
  }>;
  constructor() { }

  ngOnInit() {
  }

}
