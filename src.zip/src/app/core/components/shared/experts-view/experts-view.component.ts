import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-experts-view',
  templateUrl: './experts-view.component.html',
  styleUrls: ['./experts-view.component.scss']
})
export class ExpertsViewComponent implements OnInit {
  @Input() expertsData : any;
  // : Array<{
  //   id: any;
  //   title: any;
  //   description: any;
  //   author_name: any;
  //   author_image_url: any;
  //   title_image_url: any;
  //   date: any;
  // }> = [];
  constructor() { }

  ngOnInit() {
    if(this.expertsData){
    console.log('expertsData' + this.expertsData)}
  }

}
