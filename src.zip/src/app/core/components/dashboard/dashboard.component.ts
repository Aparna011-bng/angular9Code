import { Component, OnInit } from '@angular/core';
import { DashboardApiService } from '../../services/dashboard-api.service';
import { takeWhile } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { TokenService } from '../../services/token.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public showToolTip: boolean = false;
  public toolTipContent: string;
  public whichToolTip: string;
  public dashboardData: any;
  public dashboardStaticData: any;
  private _isComponentAlive = true;
  public generateReport: boolean;
  public tokenReceived: boolean;
  public studentName: string;

  constructor(private _getDashboardDataService: DashboardApiService, private _router: Router, public dialog: MatDialog, private _tokenService: TokenService) { }

  ngOnInit() {
    this.getTokenValue();
  }

  public getTokenValue() {
    this._tokenService.tokenProviderObservable$
      .pipe(
        // switchMap((data) => this._getAssessmentData(data))
      )
      .subscribe(this._getTokenValueHandler);
  }

  private _getTokenValueHandler = (data) => {

    if (data === null) {
      this._getDashboardData('', '');
    }
    else {
      // console.log(data.student_id);
      // console.log('Student_id' + this.student_id);
      this.studentName = data.student_name;
      this._getDashboardData(data.student_id, data.token);
      this.tokenReceived = true;
    }
  }

  public openReport() {
    this._router.navigate(['/your-report']);
  }

  private _getDashboardData(studentId, token) {

    this._getDashboardDataService.getDashboardData({
      student_id: studentId
    }, token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._getDashboardDataSuccessHandler, error: this._getDashboardDataErrorHandler });
  }

  private _getDashboardDataSuccessHandler = (data) => {
    if (data) {
      this.dashboardData = data;
      console.log(this.dashboardData);
      // console.log(this.dashboardData.blogs);
    }
  }

  private _getDashboardDataErrorHandler = (error) => {
    //error handler
    console.log(error);
  }
}
