import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { DashboardApiService } from '../../services/dashboard-api.service';
import { takeWhile } from 'rxjs/operators';
import { TokenService } from '../../services/token.service';
import { HttpRequestService } from '../../http-request.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  private _isComponentAlive = true;
  public loginInfo: any;
  public _token: any;
  constructor(public dialogRef: MatDialogRef<LoginComponent>, private _router: Router, private _tokenService: TokenService) { }

  public userDetail = {
    email: '',
    password: ''
  }

  ngOnInit() {
  }

  public sendLogin() {
    // Remove logging
    console.log(this.userDetail.email);
    console.log(this.userDetail.password);
    // Remove logging
    this._tokenService.postLoginInfo({
      email: this.userDetail.email,
      password: this.userDetail.password,
      targetURL: '/assess'
    })
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._attemptLoginSuccessHandler, error: this._attemptLoginErrorHandler });
  }

  private _attemptLoginSuccessHandler = (response) => {
    if (response) {
      this.loginInfo = response.data;
      this._token = response.headers.get('x-eduguy-auth-token');
      console.log(this._token);
      const receivedStudentInfo = {
        student_id: this.loginInfo.student_id,
        student_name: this.loginInfo.student_name,
        token: this._token
      }
      this._tokenService.setTokenVal(receivedStudentInfo);
      this.dialogRef.close();
      this._router.navigate([this.loginInfo.targetURL]);
    }
  }

  private _attemptLoginErrorHandler = (error) => {
      alert(error.error.err);
      // window.location.href = 'https://eduguy.com/';
      // window.target = ''
  }

  onNoClick(): void {
    this._router.navigate(['home'])
    this.dialogRef.close();
  }
}
