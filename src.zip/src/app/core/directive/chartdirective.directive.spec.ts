import { ChartdirectiveDirective } from './chartdirective.directive';

describe('ChartdirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new ChartdirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
