import { Directive, ViewChild } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts/ng2-charts';
@Directive({
  selector: '[appChartdirective]'
})
export class ChartdirectiveDirective {
  //@ViewChild("baseChart") chart: BaseChartDirective;

  constructor() { }

}
