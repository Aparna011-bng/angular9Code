import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HttpClientModule } from '@angular/common/http';
import { StudentProfileComponent } from './components/student-profile/student-profile.component';
import { SharedModule } from '../shared/shared.module';
import { YourReportComponent } from './components/your-report/your-report.component';
import {MatTabsModule} from '@angular/material/tabs';
import { CalendarHeatmap } from 'angular2-calendar-heatmap';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {ChartsModule} from 'ng2-charts';
import { TakeAssessmentsComponent } from './components/take-assessments/take-assessments.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { ExpertsViewComponent } from './components/shared/experts-view/experts-view.component';
import { TestimonialsComponent } from './components/shared/testimonials/testimonials.component';
import { HappeningComponent } from './components/shared/happening/happening.component';
import { AdvertiseComponent } from './components/shared/advertise/advertise.component';
import { ReportRadarChartComponent } from './components/shared/report-radar-chart/report-radar-chart.component';
import { AssessmentsModule } from '../assessments/assessments.module';
import {MatExpansionModule} from '@angular/material/expansion';
import { LoginComponent } from './components/login/login.component';
import { MatDialogModule } from '@angular/material/dialog';
import {MatFormFieldModule} from '@angular/material/form-field';
import { LoginholderComponent } from './components/loginholder/loginholder.component';
import { ReportradarAptitudeComponent } from './components/shared/reportradar-aptitude/reportradar-aptitude.component';
import { ReportRadarInterestComponent } from './components/shared/report-radar-interest/report-radar-interest.component';
import { MatCarouselModule } from '@ngmodule/material-carousel';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ChartdirectiveDirective } from './directive/chartdirective.directive';



@NgModule({
    declarations: [
        DashboardComponent, HeaderComponent, FooterComponent, StudentProfileComponent, ExpertsViewComponent, TestimonialsComponent, HappeningComponent, AdvertiseComponent, YourReportComponent,CalendarHeatmap, ReportRadarChartComponent, TakeAssessmentsComponent, LoginComponent, LoginholderComponent, ReportradarAptitudeComponent, ReportRadarInterestComponent, ChartdirectiveDirective,
    ],
    imports: [
        CommonModule, RouterModule, HttpClientModule, SharedModule, MatTabsModule, FormsModule, BrowserModule, ChartsModule, AssessmentsModule, MatExpansionModule, MatDialogModule, MatFormFieldModule, MatCarouselModule.forRoot(), ScrollingModule
    ],
    exports: [DashboardComponent, HeaderComponent, FooterComponent],
    entryComponents: [LoginComponent]

})
export class CoreModule { }
