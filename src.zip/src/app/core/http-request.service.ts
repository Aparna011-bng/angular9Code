import { Injectable } from '@angular/core';
import { catchError, map } from 'rxjs/operators'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { APP_CONSTANTS } from '../constants';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class HttpRequestService {
  // private _token = ''
  public loginInfo: any;
  constructor(private _httpClient: HttpClient, private _router: Router) { }

  // public getToken(requestBody: { email, password }){
  //   this._httpClient.request({
  //     method: APP_CONSTANTS.API_METHODS.POST,
  //     url: environment.SERVICE_APIS.ATTEMPT_LOGIN,
  //     body: requestBody
  //   })
    
  //   .subscribe(data => {
  //     if (data) {
  //       this.loginInfo = data;
  //       this._token = this.loginInfo.token
  //       console.log(this.loginInfo);
  //       console.log(this._token);
  //     } 
  //   })
  // }

  private _getHttpHeaders(headerConfig) {

    return new HttpHeaders({
      'Content-Type': headerConfig && headerConfig.contentType ? headerConfig.contentType : 'application/json',
      'Access-Control-Allow-Methods': '*',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': '*',
      // 'x-eduguy-auth-token': headerConfig && headerConfig.token ? headerConfig.token : ''
    }).set('x-eduguy-auth-token', headerConfig && headerConfig.token ? headerConfig.token : '')
  } 

  public request(requestOption): Observable<any> {
    return this._httpClient.request(
      requestOption.method,
      requestOption.url,
      {
        headers: this._getHttpHeaders(requestOption.headerConfig),
        params: requestOption.params,
        body: requestOption.body,
        observe: 'response',
        responseType: requestOption.responseType ? requestOption.responseType : 'json'
      })
      .pipe(
        map(data => this._extractData(data)),
        catchError(data => this._handleError(data))
      );
  }

  private _extractData = (response): any => {
    const data = { data: response.body, status: response.status, headers: response.headers} || {};
    console.log(data);
    return data;
  }

  private _handleError = (error): Observable<any> => {
    if(error.status === (APP_CONSTANTS.LOGOUT_ERROR_CODES[0] || APP_CONSTANTS.LOGOUT_ERROR_CODES[1])) {
      this._router.navigate(['/login']);
    }
    // alert('Please try after sometime');
    return throwError(error);

  }

}
