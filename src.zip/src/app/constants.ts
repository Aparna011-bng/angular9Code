export const APP_CONSTANTS = {
    URI: 'http://ec2-3-6-37-115.ap-south-1.compute.amazonaws.com:3000',
    API_METHODS: {
        'GET': 'GET',
        'POST': 'POST',
        'PUT': 'PUT',
        'DELETE': 'DELETE'
    },
    SUCCESS_RESPONSE_CODES: 200,
    LOGOUT_ERROR_CODES: [401, 402],
    ERROR_RESPONSE_CODES: [404, 500],
    STUDENT_ID: 'S.05'
}