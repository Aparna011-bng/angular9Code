import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './core/components/dashboard/dashboard.component';
import { PersonalityComponent } from './assessments/components/personality/personality.component';
import { PersonalityInstructionsComponent } from './assessments/components/instructions/instructions.component';
import { PersonalityTestCompletionComponent } from './assessments/components/personality-test-completion/personality-test-completion.component';
import { StudentProfileComponent } from './core/components/student-profile/student-profile.component';
import { ReasoningComponent } from './assessments/components/aptitude/components/reasoning/reasoning.component';
import { ReasoningCompletionComponent } from './assessments/components/aptitude/components/reasoning-completion/reasoning-completion.component';
import { ReasoningInstructionsComponent } from './assessments/components/aptitude/components/reasoning-instructions/reasoning-instructions.component';
import { VerbalComponent } from './assessments/components/aptitude/components/verbal/verbal.component';
import { VerbalInstructionsComponent } from './assessments/components/aptitude/components/verbal-instructions/verbal-instructions.component';
import { ReadInstructionsGuard } from './shared/guards/read-instructions.guard';
import { YourReportComponent } from './core/components/your-report/your-report.component';
import { NumericalComponent } from './assessments/components/aptitude/components/numerical/numerical.component';
import { NumericalInstructionsComponent } from './assessments/components/aptitude/components/numerical-instructions/numerical-instructions.component';
import { NumericalCompletionComponent } from './assessments/components/aptitude/components/numerical-completion/numerical-completion.component';
import { MechanicalComponent } from './assessments/components/aptitude/components/mechanical/mechanical.component';
import { MechanicalInstructionsComponent } from './assessments/components/aptitude/components/mechanical-instructions/mechanical-instructions.component';
import { MechanicalCompletionComponent } from './assessments/components/aptitude/components/mechanical-completion/mechanical-completion.component';
import { VerbalTestCompletionComponent } from './assessments/components/aptitude/components/verbal-test-completion/verbal-test-completion.component';
import { SpatialComponent } from './assessments/components/aptitude/components/spatial/spatial.component';
import { SpatialInstructionsComponent } from './assessments/components/aptitude/components/spatial-instructions/spatial-instructions.component';
import { SpatialCompletionComponent } from './assessments/components/aptitude/components/spatial-completion/spatial-completion.component';
import { ClosureInstructionComponent } from './assessments/components/aptitude/components/closure-instruction/closure-instruction.component';
import { ClosureComponent } from './assessments/components/aptitude/components/closure/closure.component';
import { ClosureCompletionComponent } from './assessments/components/aptitude/components/closure-completion/closure-completion.component';
import { TakeAssessmentsComponent } from './core/components/take-assessments/take-assessments.component';
import { InterestComponent } from './assessments/components/interest/interest.component';
import { InterestInstructionsComponent } from './assessments/components/interest-instructions/interest-instructions.component';
import { InterestCompletionComponent } from './assessments/components/interest-completion/interest-completion.component';
import { LoginholderComponent } from './core/components/loginholder/loginholder.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginholderComponent
  },
  {
    path: 'home',
    component: DashboardComponent
  },
  {
    path: 'assess',
    component: TakeAssessmentsComponent
  },
  {
    path: 'student-profile',
    component: StudentProfileComponent
  },
  {
    path: 'your-report',
    component: YourReportComponent
  },
  {
    path: 'personality',
    component: PersonalityComponent
  },
  {
    path: 'personality-test-success',
    component: PersonalityTestCompletionComponent
  },
  {
    path: 'personality-instructions',
    component: PersonalityInstructionsComponent
  },
  {
    path: 'aptitude',
    children: [
      {
        path: 'reasoning',
        children: [
          {
            path: '',
            component: ReasoningComponent
          },
          {
            path: 'instructions',
            component: ReasoningInstructionsComponent
          },
          {
            path: 'test-success',
            component: ReasoningCompletionComponent
          }
        ]
      },
      {
        path: 'verbal',
        children: [
          {
            path: '',
            component: VerbalComponent,
            canActivate: [ReadInstructionsGuard]
          },
          {
            path: 'instructions',
            component: VerbalInstructionsComponent
          },
          {
            path: 'test-success',
            component: VerbalTestCompletionComponent
          }
        ]
      },
      {
        path: 'closure',
        children: [
          {
            path: '',
            component: ClosureComponent
          },
          {
            path: 'instructions',
            component: ClosureInstructionComponent
          },
          {
            path: 'test-success',
            component: ClosureCompletionComponent
          },
        ]
      },
      {
        path: 'mechanical',
        children: [
          {
            path: '',
            component: MechanicalComponent,
          },
          {
            path: 'instructions',
            component: MechanicalInstructionsComponent
          },
          {
            path: 'test-success',
            component: MechanicalCompletionComponent
          }
        ]
      },
      {
        path: 'numerical',
        children: [
          {
            path: '',
            component: NumericalComponent
          },
          {
            path: 'instructions',
            component: NumericalInstructionsComponent
          },
          {
            path: 'test-success',
            component: NumericalCompletionComponent
          }
        ]
      },
      {
        path: 'spatial',
        children: [
          {
            path: '',
            component: SpatialComponent
          },
          {
            path: 'instructions',
            component: SpatialInstructionsComponent
          },
          {
            path: 'test-success',
            component: SpatialCompletionComponent
          }
        ]
      }
    ]
  },
  {
    path: 'interest',
    children: [
      {
        path: '',
        component: InterestComponent
      },
      {
        path: 'instructions',
        component: InterestInstructionsComponent
      },
      {
        path: 'test-success',
        component: InterestCompletionComponent
      }
    ]
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/home'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }