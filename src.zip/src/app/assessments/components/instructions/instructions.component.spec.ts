import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalityInstructionsComponent } from './instructions.component';

describe('PersonalityInstructionsComponent', () => {
  let component: PersonalityInstructionsComponent;
  let fixture: ComponentFixture<PersonalityInstructionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalityInstructionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalityInstructionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
