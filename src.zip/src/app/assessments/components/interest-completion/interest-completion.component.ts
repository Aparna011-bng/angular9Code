import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interest-completion',
  templateUrl: './interest-completion.component.html',
  styleUrls: ['./interest-completion.component.scss']
})
export class InterestCompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
