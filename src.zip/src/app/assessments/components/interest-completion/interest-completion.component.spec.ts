import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterestCompletionComponent } from './interest-completion.component';

describe('InterestCompletionComponent', () => {
  let component: InterestCompletionComponent;
  let fixture: ComponentFixture<InterestCompletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterestCompletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterestCompletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
