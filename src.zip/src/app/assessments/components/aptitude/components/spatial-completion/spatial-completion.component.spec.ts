import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpatialCompletionComponent } from './spatial-completion.component';

describe('SpatialCompletionComponent', () => {
  let component: SpatialCompletionComponent;
  let fixture: ComponentFixture<SpatialCompletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpatialCompletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpatialCompletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
