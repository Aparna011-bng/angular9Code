import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spatial-completion',
  templateUrl: './spatial-completion.component.html',
  styleUrls: ['./spatial-completion.component.scss']
})
export class SpatialCompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
