import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NumericalInstructionsComponent } from './numerical-instructions.component';

describe('NumericalInstructionsComponent', () => {
  let component: NumericalInstructionsComponent;
  let fixture: ComponentFixture<NumericalInstructionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NumericalInstructionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NumericalInstructionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
