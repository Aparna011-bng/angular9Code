import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-numerical-instructions',
  templateUrl: './numerical-instructions.component.html',
  styleUrls: ['./numerical-instructions.component.scss']
})
export class NumericalInstructionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
