import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NumericalCompletionComponent } from './numerical-completion.component';

describe('NumericalCompletionComponent', () => {
  let component: NumericalCompletionComponent;
  let fixture: ComponentFixture<NumericalCompletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NumericalCompletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NumericalCompletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
