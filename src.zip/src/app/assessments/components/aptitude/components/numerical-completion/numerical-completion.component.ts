import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-numerical-completion',
  templateUrl: './numerical-completion.component.html',
  styleUrls: ['./numerical-completion.component.scss']
})
export class NumericalCompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
