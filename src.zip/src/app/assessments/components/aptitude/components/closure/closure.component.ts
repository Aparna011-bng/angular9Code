import { Component, OnInit, Output, EventEmitter, Inject } from '@angular/core';
import { takeWhile, findIndex } from 'rxjs/operators';
import { Router } from '@angular/router';
import { CountdownEvent, CountdownConfig } from 'ngx-countdown';
import { AptitudeTestDetailService } from 'src/app/shared/services/aptitude-test-detail.service';
import { TokenService } from 'src/app/core/services/token.service';
import { APP_CONSTANTS } from 'src/app/constants';



@Component({
  selector: 'app-closure',
  templateUrl: './closure.component.html',
  styleUrls: ['./closure.component.scss']
})
export class ClosureComponent implements OnInit {

  public p: number;
  public disablePreviousButton: boolean;
  public disableNextButton: boolean;
  private _isComponentAlive = true;
  public closureTestData: any = {};
  public option_id: any;
  public checked: boolean;
  public testResponse: Array<{
    question_id: number,
    option_id: string
  }> = [];
  public config: CountdownConfig
  public storingArray: Array<any> = [];
  public testNotComplete: boolean;
  private _timefinished: boolean;
  private _minquestionsAttempted: boolean;
  private _testInvalid: boolean;
  private _submitResponseSuccess: boolean;
  private _entererdTest: boolean = false;
  private _something: boolean;
  public showToolTip: boolean = false;
  //public toolTipContent: string;
  public whichToolTip: string;
  public today: any;
  public endTime: any;
  public token: string;

  @Output() pageChange = new EventEmitter<any>();
  constructor(private _getClosureTestDataService: AptitudeTestDetailService, private _router: Router, private _tokenService: TokenService) {

  }

  closeTooltip() {
    this.showToolTip = false;
  }

  ngOnInit() {
    this.p = 1;
    // this._getClosureTestData('','');
    this.getTokenValue();
    this.today = new Date();
  }

  public getTokenValue() {
    this._tokenService.tokenProviderObservable$
      .pipe(
        // switchMap((data) => this._getAssessmentData(data))
      )
      .subscribe(this._getTokenValueHandler);
  }

  private _getTokenValueHandler = (data) => {
    console.log(data.student_id);
    this.token = data.token;
    // console.log('Student_id' + this.student_id);
    this._getClosureTestData(data.student_id, data.token);

    // this.assessmentData = this._getAssessmentData();
    // return forkJoin([this.assessmentData, this.tokenData ]);
  }


  public handleEvent(e: CountdownEvent) {
    if (e.left === 0) {
      this._timefinished = true;
      if (this._timefinished === true) {
        this.submitTestResult();
      }
    }
    else {
      this._timefinished = false;
      // this.submitTestResult();
    }
  }
  ngAfterViewInit() {
    this._something = true;
  }

  public sendAnswerVal(questionId, value) {
    if (questionId && value) {
      const index = this.testResponse.findIndex((e) => e.question_id === questionId);
      if (index === -1) {
        this.testNotComplete = true;
        this.testResponse.push({
          question_id: questionId,
          option_id: value
        });
      }
      else {
        this.testResponse[index].option_id = value;
      }
    }
    console.log(this.testResponse.sort(function (a, b) { return a.question_id - b.question_id }));
    this.storingArray = this.testResponse.sort(function (a, b) { return a.question_id - b.question_id });
    console.log(this.storingArray);
    console.log(this.storingArray.length);
    if (this.storingArray.length >= 5) {
      this._minquestionsAttempted = true;
    }
  }


  public goToPrevious() {
    if (this.p > 1)
      this.pageChange.emit(this.p--);

  }

  public goToNext() {
    console.log(this.storingArray);
    if (this.p < 4)
      this.pageChange.emit(this.p++);
  }
  private _getClosureTestData(student_id, token) {
    this._getClosureTestDataService.getClosureTestData(student_id, token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._getClosureTestDataSuccessHandler, error: this._getClosureTestDataErrorHandler });
  }

  private _getClosureTestDataSuccessHandler = (data) => {
    if (data) {
      this.closureTestData = data;
      console.log(this.closureTestData);
      this.config = {
        leftTime: (this.closureTestData.test_completion_time) * 60,
        // leftTime: 20,
        notify: 0
      }
    }
  }

  private _getClosureTestDataErrorHandler = () => {
    //redirect to error page, if any!
  }

  public submitTestResult() {
    if (!this._minquestionsAttempted && !this._timefinished) {
      alert("You can't submit the test! Please continue ");
    }
    else if (!this._minquestionsAttempted && !!this._timefinished && this._something) {
      this._router.navigate(['/dashboard']);
      alert('test invalid');
    }
    else if (this._minquestionsAttempted === true && this.storingArray.length === this.closureTestData.test_paper.questions.length && !this._timefinished) {
      this._submitResponseSuccess = true;
    }
    else if (this._minquestionsAttempted === true && !this._timefinished && this.storingArray.length !== this.closureTestData.test_paper.questions.length) {
      alert('You have some more questions to go!')
    }
    else if (this._minquestionsAttempted === true && this._timefinished) {
      this._submitResponseSuccess = true;
    }

    if (this.closureTestData && this._submitResponseSuccess) {
      this.postresults();
    }
  }

  public postresults() {
    this.endTime = new Date();
    this._getClosureTestDataService.postClosureTestResult({
      test_id: this.closureTestData.test_id,
      student_id: this.closureTestData.student_id,
      assessment_id: this.closureTestData.assessment_id,
      start_datetime: this.today,
      end_datetime: this.endTime,
      test_response: this.storingArray
    }, this.token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._setSubmitTestSuccessHandler, error: this._setSubmitTestErrorHandler });
  }

  private _setSubmitTestSuccessHandler = (data) => {
    console.log(data);
    if (data) {
      this._router.navigate(['aptitude/closure/test-success']);
    }
  }

  private _setSubmitTestErrorHandler = () => {
    this._router.navigate(['/dashboard']);
  }
  public openPersonalityToolTip() {
    this.showToolTip = true;
    //this.toolTipContent = "In this test you will <b>see a word with parts of the letters missing.</b> This “incomplete” word is followed by five “jumbled” words.";
    this.whichToolTip = 'personality';
  }

}
