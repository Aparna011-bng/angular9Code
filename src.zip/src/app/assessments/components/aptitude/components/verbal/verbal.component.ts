import { Component, OnInit } from '@angular/core';
import { AptitudeTestDetailService } from 'src/app/shared/services/aptitude-test-detail.service';
import { takeWhile } from 'rxjs/operators';
import { CountdownConfig, CountdownEvent } from 'ngx-countdown';
import { Router } from '@angular/router';
import { TokenService } from 'src/app/core/services/token.service';
import { APP_CONSTANTS } from 'src/app/constants';

@Component({
  selector: 'app-verbal',
  templateUrl: './verbal.component.html',
  styleUrls: ['./verbal.component.scss']
})
export class VerbalComponent implements OnInit {
  public verbalTestData: any;
  public config: CountdownConfig
  public configSectionTwo: CountdownConfig
  private _isComponentAlive: boolean = true;
  public testResponse: Array<{
    question_id: number,
    option_id: string,
    section_id: string
  }> = [];
  public storingArray: Array<any> = [];
  public partOneCompleted: boolean = false;
  public today: any;
  public endTime: any;
  public token: string;

  constructor(private _aptitudeTestService: AptitudeTestDetailService, private _router: Router, private _tokenService: TokenService) { }

  ngOnInit() {
    this.getTokenValue();
    // this._getVerbalTestData('', '');

    this.today = new Date();
  }

  public getTokenValue() {
    this._tokenService.tokenProviderObservable$
      .pipe(
        // switchMap((data) => this._getAssessmentData(data))
      )
      .subscribe(this._getTokenValueHandler);
  }

  private _getTokenValueHandler = (data) => {
    console.log(data.student_id);
    this.token = data.token;
    // console.log('Student_id' + this.student_id);
    this._getVerbalTestData(data.student_id, data.token);

    // this.assessmentData = this._getAssessmentData();
    // return forkJoin([this.assessmentData, this.tokenData ]);
  }

  public handleEvent(e: CountdownEvent) {
    if (e.left === 0) {
      // this._timefinished = true;
      // if (this._timefinished === true) {
      //   // this.submitTestResult();
      // }
    }
    else {
      // this._timefinished = false;
      // this.submitTestResult();
    }
  }

  public submitOne() {
    // Please change 1 to 15
    if (this.testResponse.length === 24) {
      this._postTestResults();
    }
    else if (this.testResponse.length < 15) {
      alert('Heading to Part 2? Please complete all the questions in Part 1 first');
    }
    else if (this.testResponse.length >= 15 && this.partOneCompleted && this.testResponse.length < 24) {
      alert('Please answer all the questions to complete the test!');
    }
    else {
      this.partOneCompleted = true;
    }
    this.config = {
      leftTime: (this.verbalTestData.parts.part_2.test_completion_time) * 60,
      // leftTime: 100,
      notify: 0
    }
  }

  private _postTestResults() {
    this.endTime = new Date();

    this._aptitudeTestService.postVerbalTestResult({
      test_id: this.verbalTestData.test_id,
      student_id: this.verbalTestData.student_id,
      assessment_id: this.verbalTestData.assessment_id,
      start_datetime: this.today,
      end_datetime: this.endTime,
      test_response: this.storingArray
    }, this.token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._setSubmitTestSuccessHandler, error: this._setSubmitTestErrorHandler });
  }

  private _setSubmitTestSuccessHandler = (data) => {
    console.log(data);
    if (data) {
      this._router.navigate(['aptitude/verbal/test-success']);
    }
  }

  private _setSubmitTestErrorHandler = () => {
    // 
  }

  public sendAnswerVal(sectionId, questionId, value) {
    if (questionId && value) {
      const index = this.testResponse.findIndex((e) => e.question_id === questionId);
      if (index === -1) {
        // this.testNotComplete = true;
        this.testResponse.push({
          section_id: sectionId,
          question_id: questionId,
          option_id: value
        });
      }
      else {
        this.testResponse[index].option_id = value;
      }
    }
    console.log(this.testResponse.sort(function (a, b) { return a.question_id - b.question_id }));
    this.storingArray = this.testResponse.sort(function (a, b) { return a.question_id - b.question_id });
    console.log(this.storingArray);
    console.log(this.storingArray.length);
  }

  private _getVerbalTestData(student_id, token) {
    this._aptitudeTestService.getVerbalTestData(student_id, token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
    )
      .subscribe({ next: this._getVerbalTestDataSuccessHandler, error: this._getVerbalTestDataErrorHandler });
  }
  private _getVerbalTestDataSuccessHandler = (data) => {
    if (data) {
      this.verbalTestData = data;
      console.log(this.verbalTestData);
      this.config = {
        leftTime: (this.verbalTestData.parts.part_1.test_completion_time) * 60,
        // leftTime: 30,
        notify: 0
      }
    }
  }

  private _getVerbalTestDataErrorHandler = () => {
    // error handle
  }
}
