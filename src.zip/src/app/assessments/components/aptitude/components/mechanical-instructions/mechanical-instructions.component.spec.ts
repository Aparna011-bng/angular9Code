import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MechanicalInstructionsComponent } from './mechanical-instructions.component';

describe('MechanicalInstructionsComponent', () => {
  let component: MechanicalInstructionsComponent;
  let fixture: ComponentFixture<MechanicalInstructionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MechanicalInstructionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MechanicalInstructionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
