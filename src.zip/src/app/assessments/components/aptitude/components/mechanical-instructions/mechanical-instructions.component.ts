import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mechanical-instructions',
  templateUrl: './mechanical-instructions.component.html',
  styleUrls: ['./mechanical-instructions.component.scss']
})
export class MechanicalInstructionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
