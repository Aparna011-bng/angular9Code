import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reasoning-instructions',
  templateUrl: './reasoning-instructions.component.html',
  styleUrls: ['./reasoning-instructions.component.scss']
})
export class ReasoningInstructionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
