import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReasoningInstructionsComponent } from './reasoning-instructions.component';

describe('ReasoningInstructionsComponent', () => {
  let component: ReasoningInstructionsComponent;
  let fixture: ComponentFixture<ReasoningInstructionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReasoningInstructionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReasoningInstructionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
