import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClosureCompletionComponent } from './closure-completion.component';

describe('ClosureCompletionComponent', () => {
  let component: ClosureCompletionComponent;
  let fixture: ComponentFixture<ClosureCompletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClosureCompletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClosureCompletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
