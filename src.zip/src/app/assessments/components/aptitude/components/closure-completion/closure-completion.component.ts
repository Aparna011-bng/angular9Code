import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-closure-completion',
  templateUrl: './closure-completion.component.html',
  styleUrls: ['./closure-completion.component.scss']
})
export class ClosureCompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
