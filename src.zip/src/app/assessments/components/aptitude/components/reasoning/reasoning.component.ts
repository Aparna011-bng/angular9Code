import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { PersonalityTestDetailService } from 'src/app/shared/services/personality-test-detail.service';
import { Router } from '@angular/router';
import { takeWhile } from 'rxjs/operators';
import { CountdownConfig, CountdownEvent } from 'ngx-countdown';
import { AptitudeTestDetailService } from 'src/app/shared/services/aptitude-test-detail.service';
import { TokenService } from 'src/app/core/services/token.service';
import { APP_CONSTANTS } from 'src/app/constants';

@Component({
  selector: 'app-reasoning',
  templateUrl: './reasoning.component.html',
  styleUrls: ['./reasoning.component.scss']
})
export class ReasoningComponent implements OnInit {
  public reasoningTestData: any
  public config: CountdownConfig
  private _isComponentAlive = true;
  public testResponse: Array<{
    question_id: number,
    option_id: string
  }> = [];
  public storingArray: Array<any> = [];
  private _minquestionsAttempted: boolean;
  public today: any;
  public endTime: any;
  public token: string

  constructor(private _getReasoningTestDataService: AptitudeTestDetailService, private _router: Router, private _tokenService: TokenService) { }

  ngOnInit() {
    this.getTokenValue();
    this.today = new Date();
    // this._getReasoningTestData('', '');
  }

  public handleEvent(e: CountdownEvent) {
    if (e.left === 0) {
    }
  }

  public getTokenValue() {
    this._tokenService.tokenProviderObservable$
      .pipe(
        // switchMap((data) => this._getAssessmentData(data))
      )
      .subscribe(this._getTokenValueHandler);
  }

  private _getTokenValueHandler = (data) => {
    console.log(data.student_id);
    this.token = data.token
    // console.log('Student_id' + this.student_id);
    this._getReasoningTestData(data.student_id, data.token);

    // this.assessmentData = this._getAssessmentData();
    // return forkJoin([this.assessmentData, this.tokenData ]);
  }


  public sendAnswerVal(questionId, value) {
    if (questionId && value) {
      const index = this.testResponse.findIndex((e) => e.question_id === questionId);
      if (index === -1) {
        // this._testNotComplete = true;
        this.testResponse.push({
          question_id: questionId,
          option_id: value
        });
      }
      else {
        this.testResponse[index].option_id = value;
      }
    }
    console.log(this.testResponse.sort(function (a, b) { return a.question_id - b.question_id }));
    this.storingArray = this.testResponse.sort(function (a, b) { return a.question_id - b.question_id });
    console.log(this.storingArray);
    console.log(this.storingArray.length);
    if (this.storingArray.length === 12) {
      this._minquestionsAttempted = true;
    }
  }

  private _getReasoningTestData(student_id, token) {
    this._getReasoningTestDataService.getReasoningTestData(student_id, token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._getReasoningTestDataSuccessHandler, error: this._getReasoningTestDataErrorHandler });
  }


  private _getReasoningTestDataSuccessHandler = (data) => {
    if (data) {
      this.reasoningTestData = data;
      console.log(this.reasoningTestData);
      this.config = {
        leftTime: (this.reasoningTestData.test_completion_time) * 60,
        // leftTime: 30,
        notify: 0
      }
    }
  }

  private _getReasoningTestDataErrorHandler = () => {

  }

  public submitTest() {
    this.endTime = new Date();

    if (this._minquestionsAttempted) {
      this._getReasoningTestDataService.postReasoningTestResult({
        test_id: this.reasoningTestData.test_id,
        student_id: this.reasoningTestData.student_id,
        assessment_id: this.reasoningTestData.assessment_id,
        start_datetime: this.today,
        end_datetime: this.endTime,
        test_response: this.storingArray
      }, this.token)
        .pipe(
          takeWhile(() => this._isComponentAlive)
        )
        .subscribe({ next: this._setSubmitTestSuccessHandler, error: this._setSubmitTestErrorHandler });
    }
    else {
      alert('Please answer all the questions');
    }
  }
  private _setSubmitTestSuccessHandler = (data) => {
    console.log(data);
    if (data) {
      this._router.navigate(['aptitude/reasoning/test-success']);
    }
  }

  private _setSubmitTestErrorHandler = () => {
    this._router.navigate(['/dashboard']);
  }
}

