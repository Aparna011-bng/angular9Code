import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spatial-instructions',
  templateUrl: './spatial-instructions.component.html',
  styleUrls: ['./spatial-instructions.component.scss']
})
export class SpatialInstructionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
