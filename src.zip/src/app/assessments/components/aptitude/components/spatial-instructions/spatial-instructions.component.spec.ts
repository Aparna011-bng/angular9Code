import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpatialInstructionsComponent } from './spatial-instructions.component';

describe('SpatialInstructionsComponent', () => {
  let component: SpatialInstructionsComponent;
  let fixture: ComponentFixture<SpatialInstructionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpatialInstructionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpatialInstructionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
