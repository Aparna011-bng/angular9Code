import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verbal-instructions',
  templateUrl: './verbal-instructions.component.html',
  styleUrls: ['./verbal-instructions.component.scss']
})
export class VerbalInstructionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
