import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerbalInstructionsComponent } from './verbal-instructions.component';

describe('VerbalInstructionsComponent', () => {
  let component: VerbalInstructionsComponent;
  let fixture: ComponentFixture<VerbalInstructionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerbalInstructionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerbalInstructionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
