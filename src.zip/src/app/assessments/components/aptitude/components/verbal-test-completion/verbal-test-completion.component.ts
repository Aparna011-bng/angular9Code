import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verbal-test-completion',
  templateUrl: './verbal-test-completion.component.html',
  styleUrls: ['./verbal-test-completion.component.scss']
})
export class VerbalTestCompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
