import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerbalTestCompletionComponent } from './verbal-test-completion.component';

describe('VerbalTestCompletionComponent', () => {
  let component: VerbalTestCompletionComponent;
  let fixture: ComponentFixture<VerbalTestCompletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerbalTestCompletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerbalTestCompletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
