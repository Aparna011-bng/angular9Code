import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReasoningCompletionComponent } from './reasoning-completion.component';

describe('ReasoningCompletionComponent', () => {
  let component: ReasoningCompletionComponent;
  let fixture: ComponentFixture<ReasoningCompletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReasoningCompletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReasoningCompletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
