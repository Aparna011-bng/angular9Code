import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reasoning-completion',
  templateUrl: './reasoning-completion.component.html',
  styleUrls: ['./reasoning-completion.component.scss']
})
export class ReasoningCompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
