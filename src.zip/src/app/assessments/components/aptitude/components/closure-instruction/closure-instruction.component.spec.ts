import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClosureInstructionComponent } from './closure-instruction.component';

describe('ClosureInstructionComponent', () => {
  let component: ClosureInstructionComponent;
  let fixture: ComponentFixture<ClosureInstructionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClosureInstructionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClosureInstructionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
