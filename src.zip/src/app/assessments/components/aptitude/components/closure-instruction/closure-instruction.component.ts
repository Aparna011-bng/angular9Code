import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-closure-instruction',
  templateUrl: './closure-instruction.component.html',
  styleUrls: ['./closure-instruction.component.scss']
})
export class ClosureInstructionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
