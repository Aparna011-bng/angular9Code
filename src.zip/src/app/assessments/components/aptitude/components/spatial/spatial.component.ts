import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AptitudeTestDetailService } from 'src/app/shared/services/aptitude-test-detail.service';
import { takeWhile } from 'rxjs/operators';
import { CountdownConfig, CountdownEvent } from 'ngx-countdown';
import { Router } from '@angular/router';
import { TokenService } from 'src/app/core/services/token.service';
import { APP_CONSTANTS } from 'src/app/constants';

@Component({
  selector: 'app-spatial',
  templateUrl: './spatial.component.html',
  styleUrls: ['./spatial.component.scss']
})
export class SpatialComponent implements OnInit {
  public btnClicked: boolean;
  public p: number;
  private _isComponentAlive = true;
  public spatialTestData: any;
  public config: CountdownConfig
  public storingArray: Array<any> = [];
  public testResponse: Array<{
    question_id: string,
    option_id: number,
    option_choice_id: string
  }> = [];
  public testNotComplete: boolean;
  private _timefinished: boolean;
  private _minquestionsAttempted: boolean;
  private _submitResponseSuccess: boolean;
  private _something: boolean;
  @Output() pageChange = new EventEmitter<any>();
  public tempIDs: Array<any> = [];
  public showToolTip: boolean;
  public highlightLeft: boolean;
  public highlightRight: boolean;
  public today: any;
  public endTime: any;
  public token: string;

  constructor(private _getSpatialAbilityTestService: AptitudeTestDetailService, private _router: Router, private _tokenService: TokenService) { }

  ngOnInit() {
    this.p = 1;
    this.getTokenValue();
    this.today = new Date();
    // this._getSpatialTestData('', '');

  }


  public getTokenValue() {
    this._tokenService.tokenProviderObservable$
      .pipe(
        // switchMap((data) => this._getAssessmentData(data))
      )
      .subscribe(this._getTokenValueHandler);
  }

  private _getTokenValueHandler = (data) => {
    console.log(data.student_id);
    this.token = data.token;
    // console.log('Student_id' + this.student_id);
    this._getSpatialTestData(data.student_id, data.token);

    // this.assessmentData = this._getAssessmentData();
    // return forkJoin([this.assessmentData, this.tokenData ]);
  }

  public handleEvent(e: CountdownEvent) {
    if (e.left === 0) {
      this._timefinished = true;
      if (this._timefinished === true) {
        this.submitTestResult();
      }
    }
    else {
      this._timefinished = false;
      // this.submitTestResult();
    }
  }
  ngAfterViewInit() {
    this._something = true;
  }

  public openPersonalityToolTip() {
    this.showToolTip = true;
  }

  public closeTooltip() {
    this.showToolTip = false;
  }
  public sendAnswerVal(questionsId, questionId, value, id, whichButton) {
    // this.tempIDs.push(id);
    // if (this.tempIDs.includes(id)) {
    //   selectedBtn.removeAttribute('style');
    // }
    var selectedBtn = document.getElementById(id);

    // var selectedBtnClass = document.getElementsByClassName(className);
    if (whichButton === 'S') {
      this.highlightLeft = true;
      if (this.highlightLeft) {
        selectedBtn.classList.add("checkingClick");
        // console.log(selectedBtn.parentElement.parentElement.lastElementChild.lastElementChild);
        selectedBtn.parentElement.parentElement.lastElementChild.lastElementChild.classList.remove("checkingClick");
      }
    }
    else {
      this.highlightRight = true;
      if (this.highlightRight) {
        // this.highlightLeft=false;
        // // selectedBtn.removeAttribute("style");
        selectedBtn.classList.add("checkingClick");
        console.log(selectedBtn.parentElement.parentElement.firstElementChild.firstElementChild);
        selectedBtn.parentElement.parentElement.firstElementChild.firstElementChild.classList.remove("checkingClick");
      }
    }
    // this.btnClicked = true;

    if (questionsId && questionId && value) {
      const index = this.testResponse.findIndex((e) => e.option_id === questionId && e.question_id === questionsId);
      if (index === -1) {
        this.testNotComplete = true;
        this.testResponse.push({
          question_id: questionsId,
          option_id: questionId,
          option_choice_id: value
        });
      }
      else {
        this.testResponse[index].option_choice_id = value;
      }
    }
    console.log(this.testResponse);
    this.storingArray = this.testResponse.sort(function (a, b) { return a.option_id - b.option_id });
    console.log(this.storingArray);
    console.log(this.testResponse.length);
    if (this.testResponse.length >= 5) {
      this._minquestionsAttempted = true;
    }
  }

  public goToPrevious() {
    if (this.p > 1)
      this.pageChange.emit(this.p--);
  }

  public goToNext() {
    console.log(this.storingArray);
    if (this.p < 4)
      this.pageChange.emit(this.p++);
  }

  public submitTestResult() {
    if (!this._minquestionsAttempted && !this._timefinished) {
      alert("You can't submit the test! Please continue ");
    }
    else if (!this._minquestionsAttempted && !!this._timefinished && this._something) {
      this._router.navigate(['/dashboard']);
      alert('test invalid');

    }
    else if (this._minquestionsAttempted === true && !this._timefinished) {
      alert('You have 15 more questions to go!')
      // this.postresults();
    }
    else if (this._minquestionsAttempted === true && this._timefinished) {
      this._submitResponseSuccess = true;
    }

    if (this.spatialTestData && this._submitResponseSuccess) {
      this.postresults();
    }
  }

  public postresults() {
    this.endTime = new Date();

    this._getSpatialAbilityTestService.postSpatialTestResult({
      test_id: this.spatialTestData.test_id,
      student_id: this.spatialTestData.student_id,
      assessment_id: this.spatialTestData.assessment_id,
      start_datetime: this.today,
      end_datetime: this.endTime,
      test_response: this.testResponse
    }, this.token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._setSubmitTestSuccessHandler, error: this._setSubmitTestErrorHandler });
  }

  private _setSubmitTestSuccessHandler = (data) => {
    console.log(data);
    if (data) {
      this._router.navigate(['/aptitude/spatial/test-success']);
    }
  }

  private _setSubmitTestErrorHandler = () => {
    this._router.navigate(['/dashboard']);
  }


  private _getSpatialTestData(student_id, token) {
    this._getSpatialAbilityTestService.getSpatialTestData(student_id, token)
      .pipe(
        takeWhile(() => this._isComponentAlive)
      )
      .subscribe({ next: this._getSpatialTestDataSuccessHandler, error: this._getSpatialTestDataErrorHandler });
  }

  private _getSpatialTestDataSuccessHandler = (data) => {
    if (data) {
      this.spatialTestData = data;
      console.log(this.spatialTestData);
      this.config = {
        leftTime: (this.spatialTestData.test_completion_time) * 60,
        // leftTime: 30,
        notify: 0
      }
    }
  }

  private _getSpatialTestDataErrorHandler = () => {
    // error
  }
}
