import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mechanical-completion',
  templateUrl: './mechanical-completion.component.html',
  styleUrls: ['./mechanical-completion.component.scss']
})
export class MechanicalCompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
