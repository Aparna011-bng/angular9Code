import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MechanicalCompletionComponent } from './mechanical-completion.component';

describe('MechanicalCompletionComponent', () => {
  let component: MechanicalCompletionComponent;
  let fixture: ComponentFixture<MechanicalCompletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MechanicalCompletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MechanicalCompletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
