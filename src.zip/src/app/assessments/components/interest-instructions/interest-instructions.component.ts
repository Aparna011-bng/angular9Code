import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interest-instructions',
  templateUrl: './interest-instructions.component.html',
  styleUrls: ['./interest-instructions.component.scss']
})
export class InterestInstructionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
