import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalityTestCompletionComponent } from './personality-test-completion.component';

describe('PersonalityTestCompletionComponent', () => {
  let component: PersonalityTestCompletionComponent;
  let fixture: ComponentFixture<PersonalityTestCompletionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalityTestCompletionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalityTestCompletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
