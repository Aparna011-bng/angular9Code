import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personality-test-completion',
  templateUrl: './personality-test-completion.component.html',
  styleUrls: ['./personality-test-completion.component.scss']
})
export class PersonalityTestCompletionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
