import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instructions-banner',
  templateUrl: './instructions-banner.component.html',
  styleUrls: ['./instructions-banner.component.scss']
})
export class InstructionsBannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
