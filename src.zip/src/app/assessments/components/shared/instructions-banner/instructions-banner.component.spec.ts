import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructionsBannerComponent } from './instructions-banner.component';

describe('InstructionsBannerComponent', () => {
  let component: InstructionsBannerComponent;
  let fixture: ComponentFixture<InstructionsBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstructionsBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstructionsBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
