import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instruction-card',
  templateUrl: './instruction-card.component.html',
  styleUrls: ['./instruction-card.component.scss']
})
export class InstructionCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
