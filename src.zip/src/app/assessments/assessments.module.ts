import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { PersonalityComponent } from './components/personality/personality.component';
import { InstructionsBannerComponent } from './components/shared/instructions-banner/instructions-banner.component';
import { InstructionCardComponent } from './components/shared/instruction-card/instruction-card.component';
import { PersonalityTestCompletionComponent } from './components/personality-test-completion/personality-test-completion.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';
import { CountdownModule } from 'ngx-countdown';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { ReasoningComponent } from './components/aptitude/components/reasoning/reasoning.component';
import { ReasoningCompletionComponent } from './components/aptitude/components/reasoning-completion/reasoning-completion.component';
import { VerbalComponent } from './components/aptitude/components/verbal/verbal.component';
import { NumericalComponent } from './components/aptitude/components/numerical/numerical.component';
import { NumericalInstructionsComponent } from './components/aptitude/components/numerical-instructions/numerical-instructions.component';
import { NumericalCompletionComponent } from './components/aptitude/components/numerical-completion/numerical-completion.component';
import { MechanicalComponent } from './components/aptitude/components/mechanical/mechanical.component';
import { MechanicalInstructionsComponent } from './components/aptitude/components/mechanical-instructions/mechanical-instructions.component';
import { MechanicalCompletionComponent } from './components/aptitude/components/mechanical-completion/mechanical-completion.component';
import { VerbalTestCompletionComponent } from './components/aptitude/components/verbal-test-completion/verbal-test-completion.component';
import { SpatialComponent } from './components/aptitude/components/spatial/spatial.component';
import { SpatialInstructionsComponent } from './components/aptitude/components/spatial-instructions/spatial-instructions.component';
import { SpatialCompletionComponent } from './components/aptitude/components/spatial-completion/spatial-completion.component';
import {MatButtonModule} from '@angular/material/button';
import { ClosureComponent } from './components/aptitude/components/closure/closure.component';
import { ClosureInstructionComponent } from './components/aptitude/components/closure-instruction/closure-instruction.component';
import { ClosureCompletionComponent } from './components/aptitude/components/closure-completion/closure-completion.component';
import { InterestComponent } from './components/interest/interest.component';
import { InterestCompletionComponent } from './components/interest-completion/interest-completion.component';
import { InterestInstructionsComponent } from './components/interest-instructions/interest-instructions.component';


@NgModule({
  declarations: [
        PersonalityComponent,
        InstructionsBannerComponent,
        InstructionCardComponent,
        PersonalityTestCompletionComponent,
        ReasoningComponent,
        ReasoningCompletionComponent,
        VerbalComponent,
        NumericalComponent,
        NumericalInstructionsComponent,
        NumericalCompletionComponent,
        MechanicalComponent,
        MechanicalInstructionsComponent,
        MechanicalCompletionComponent,
        VerbalTestCompletionComponent,
        SpatialComponent,
        SpatialInstructionsComponent,
        SpatialCompletionComponent,
        ClosureComponent,
        ClosureInstructionComponent,
        ClosureCompletionComponent,
        InterestComponent,
        InterestCompletionComponent,
        InterestInstructionsComponent
  ],
  imports: [
    CommonModule, RouterModule,  NgxPaginationModule, FormsModule, CountdownModule, PerfectScrollbarModule,MatButtonModule
  ],
  // tslint:disable-next-line: max-line-length
  exports: [PersonalityComponent,InstructionsBannerComponent,InstructionCardComponent
  ],

})
export class AssessmentsModule { }
