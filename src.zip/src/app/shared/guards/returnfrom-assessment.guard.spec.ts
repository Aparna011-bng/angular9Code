import { TestBed, async, inject } from '@angular/core/testing';

import { ReturnfromAssessmentGuard } from './returnfrom-assessment.guard';

describe('ReturnfromAssessmentGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReturnfromAssessmentGuard]
    });
  });

  it('should ...', inject([ReturnfromAssessmentGuard], (guard: ReturnfromAssessmentGuard) => {
    expect(guard).toBeTruthy();
  }));
});
