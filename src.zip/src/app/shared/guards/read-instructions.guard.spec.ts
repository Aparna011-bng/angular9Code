import { TestBed, async, inject } from '@angular/core/testing';

import { ReadInstructionsGuard } from './read-instructions.guard';

describe('ReadInstructionsGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReadInstructionsGuard]
    });
  });

  it('should ...', inject([ReadInstructionsGuard], (guard: ReadInstructionsGuard) => {
    expect(guard).toBeTruthy();
  }));
});
