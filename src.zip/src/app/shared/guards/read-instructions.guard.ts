import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReadInstructionsGuard implements CanActivate {
  constructor(private _router: Router) { }
  public redirectUrl = '/aptitude/verbal/instructions';
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    // return this._router.navigateByUrl(this.redirectUrl);
    return true;
  }

}
