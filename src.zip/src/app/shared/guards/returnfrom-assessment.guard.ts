import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';
import { PersonalityComponent } from 'src/app/assessments/components/personality/personality.component';

@Injectable({
  providedIn: 'root'
})
export class ReturnfromAssessmentGuard implements CanDeactivate<PersonalityComponent> {

  canDeactivate(component: PersonalityComponent) {
    if(component.testNotComplete){
      console.log('guard activate');
      return false;
    }
    else {
      console.log('Test complete');
      return true;
    }
    // return component.testNotComplete ? false : true;
  }
}
