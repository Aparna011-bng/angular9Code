import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-profile-detail-holder',
  templateUrl: './profile-detail-holder.component.html',
  styleUrls: ['./profile-detail-holder.component.scss']
})
export class ProfileDetailHolderComponent implements OnInit {
  @Input() studentData: any;
  @Input() authorDetail: any;
  constructor() { }

  ngOnInit() {
  }

}