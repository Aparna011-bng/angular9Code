import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileDetailHolderComponent } from './profile-detail-holder.component';

describe('ProfileDetailHolderComponent', () => {
  let component: ProfileDetailHolderComponent;
  let fixture: ComponentFixture<ProfileDetailHolderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileDetailHolderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileDetailHolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
