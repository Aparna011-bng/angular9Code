import { TestBed } from '@angular/core/testing';

import { AptitudeTestDetailService } from './aptitude-test-detail.service';

describe('AptitudeTestDetailService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AptitudeTestDetailService = TestBed.get(AptitudeTestDetailService);
    expect(service).toBeTruthy();
  });
});
