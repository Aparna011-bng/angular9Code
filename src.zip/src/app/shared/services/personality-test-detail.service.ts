import { Injectable } from '@angular/core';
import { HttpRequestService } from 'src/app/core/http-request.service';
import { Observable } from 'rxjs';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PersonalityTestDetailService {

  constructor(private _httpReqService: HttpRequestService) { }

  // Personality Test

  public getPersonalityTestData(studentId, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_PERSONALITY_TEST_DATA + studentId,
      headerConfig: {token: token, contentType: 'application/json'}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  public postPersonalityTestresult(requestBody: { test_id, student_id, assessment_id, start_datetime, end_datetime, test_response }, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.POST_PERSONALITY_TEST_RESULT,
      body: requestBody,
      headerConfig: {token: token}
    })
  }
  // Personality Test

  private _extractResponse = (response: { data: any, status: number }) => {
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data;
    } else {
      return false;
    }
  }
}
