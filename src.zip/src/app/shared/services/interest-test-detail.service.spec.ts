import { TestBed } from '@angular/core/testing';

import { InterestTestDetailService } from './interest-test-detail.service';

describe('InterestTestDetailService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InterestTestDetailService = TestBed.get(InterestTestDetailService);
    expect(service).toBeTruthy();
  });
});
