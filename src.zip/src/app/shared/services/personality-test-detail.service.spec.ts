import { TestBed } from '@angular/core/testing';

import { PersonalityTestDetailService } from './personality-test-detail.service';

describe('PersonalityTestDetailService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PersonalityTestDetailService = TestBed.get(PersonalityTestDetailService);
    expect(service).toBeTruthy();
  });
});
