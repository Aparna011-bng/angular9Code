import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APP_CONSTANTS } from 'src/app/constants';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { HttpRequestService } from 'src/app/core/http-request.service';

@Injectable({
  providedIn: 'root'
})
export class AptitudeTestDetailService {

  constructor(private _httpReqService: HttpRequestService) { }

  //  GET Reasoning Ability 
  public getReasoningTestData(studentId, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_APTITUDE_REASONING_TEST + studentId,
      headerConfig: {token: token}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  // POST Reasoning Ability
  public postReasoningTestResult(requestBody: { test_id, student_id, assessment_id, start_datetime, end_datetime, test_response }, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.POST_APTITUDE_REASONING_TEST_RESULT,
      body: requestBody,
      headerConfig: {token: token}
    })
  }

  //  Get Verbal Ability 
  public getVerbalTestData(studentId, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_APTITUDE_VERBAL_TEST + studentId,
      headerConfig: {token: token}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  // Post Verbal Ability
  public postVerbalTestResult(requestBody: { test_id, student_id, assessment_id, start_datetime, end_datetime, test_response }, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.POST_APTITUDE_VERBAL_TEST_RESULT,
      body: requestBody,
      headerConfig: {token: token}
    })
  }

  //  Get Numerical Ability 
  public getNumericalTestData(studentId, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_APTITUDE_NUMERICAL_TEST + studentId,
      headerConfig: {token: token}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }    
  // Post Numerical Ability
  public postNumericalTestResult(requestBody:  { test_id, student_id, assessment_id, start_datetime, end_datetime, test_response }, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.POST_APTITUDE_NUMERICAL_TEST_RESULT,
      body: requestBody,
      headerConfig: {token: token}
    })
  }
    
  //  Get Closure Ability 
  public getClosureTestData(studentId, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_APTITUDE_CLOSURE_TEST + studentId,
      headerConfig: {token: token}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  // Post Closure Ability
  public postClosureTestResult(requestBody:  { test_id, student_id, assessment_id, start_datetime, end_datetime, test_response }, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.POST_APTITUDE_CLOSURE_TEST_RESULT,
      body: requestBody,
      headerConfig: {token: token}
    })
  }

  // GET MECHANICAL ABILITY
  public getMechTestData(studentId, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_APTITUDE_MECH_TEST + studentId,
      headerConfig: {token: token}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  // Post Mechanical Ability
  public postMechanicalTestResult(requestBody: { test_id, student_id, assessment_id, start_datetime, end_datetime, test_response }, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.POST_APTITUDE_MECH_TEST_RESULT,
      body: requestBody,
      headerConfig: {token: token}
    })
  }

  // GET SPATIAL ABILITY
  public getSpatialTestData(studentId, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.GET,
      url: environment.SERVICE_APIS.GET_APTITUDE_SPATIAL_TEST + studentId,
      headerConfig: {token: token}
    })
      .pipe(
        map(response => this._extractResponse(response))
      );
  }

  // Post SPATIAL Ability
  public postSpatialTestResult(requestBody: { test_id, student_id, assessment_id, start_datetime, end_datetime, test_response }, token): Observable<any> {
    return this._httpReqService.request({
      method: APP_CONSTANTS.API_METHODS.POST,
      url: environment.SERVICE_APIS.POST_APTITUDE_SPATIAL_TEST_RESULT,
      body: requestBody,
      headerConfig: {token: token}
    })
  }

  private _extractResponse = (response: { data: any, status: number }) => {
    if (response.status === APP_CONSTANTS.SUCCESS_RESPONSE_CODES) {
      return response.data;
    } else {
      return false;
    }
  }
}
