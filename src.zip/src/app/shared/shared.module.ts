import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PersonalityInstructionsComponent } from '../assessments/components/instructions/instructions.component';
import { RouterModule } from '@angular/router';
import { AssessmentsModule } from '../assessments/assessments.module';
import { ProfileDetailHolderComponent } from './components/profile-detail-holder/profile-detail-holder.component';
import { ReasoningInstructionsComponent } from '../assessments/components/aptitude/components/reasoning-instructions/reasoning-instructions.component';
import { VerbalInstructionsComponent } from '../assessments/components/aptitude/components/verbal-instructions/verbal-instructions.component';



@NgModule({
  declarations: [
    PersonalityInstructionsComponent,
        ProfileDetailHolderComponent,
        ReasoningInstructionsComponent,
        VerbalInstructionsComponent
  ],
  imports: [
    CommonModule, RouterModule, AssessmentsModule

  ],
  // tslint:disable-next-line: max-line-length
  exports: [PersonalityInstructionsComponent,ProfileDetailHolderComponent],

})
export class SharedModule { }
